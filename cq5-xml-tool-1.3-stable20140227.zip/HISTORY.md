# cq5-xml-tool

## 1.2 - stable
- Add "Key Technical Feature" in Preview view.
- Fix convert feature for "New EU" format (Node "Key specs").

## 0.5 - beta
- Add support for new EU xml format.

## 0.4 - beta
- Now, the textfield has been changed to textarea, with automatic resizing feature provided by @Yuan Dexin.
- The value of node TechnicalFeature's transAttributeName attribute is now fixed to "TechnicalFeature".

## 0.3 - beta
- Some bugs fixed.

## 0.2 - beta
- Changed attributeName and nodeName's naming rule of "Technical Feature".
- Fixed a bug which made newly added node's trim feature invalid.
- Made "See All Specs" modal can show HTML code's effect.

## 0.1 - beta
Initial release.