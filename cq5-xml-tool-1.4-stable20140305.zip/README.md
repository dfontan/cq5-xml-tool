# cq5-xml-tool v1.2

Finally, the XML Tool has been developed by Xu Hang. You can use it to preview CQ5 XML or edit CQ5 XML or transfer the local xml(EU and RU) which provided by customer to the right style. 
If possible, please help to test it again even though Qiao shan liang had tested already.  

Any question or problem about this tool, pls feel free to call me. thx!