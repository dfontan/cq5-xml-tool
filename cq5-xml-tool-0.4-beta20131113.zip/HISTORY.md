# cq5-xml-tool

## 0.4
- Now, the textfield has been changed to textarea, with automatic resizing feature provided by @Yuan Dexin.
- The value of node TechnicalFeature's transAttributeName attribute is now fixed to "TechnicalFeature"

## 0.3
- Some bugs fixed.

## 0.2
- Changed attributeName and nodeName's naming rule of "Technical Feature".
- Fixed a bug which made newly added node's trim feature invalid.
- Made "See All Specs" modal can show HTML code's effect.

## 0.1
Initial release.